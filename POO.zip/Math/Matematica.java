package Math;

public class Matematica {
	
	//metodos que retornam valores
	//pois ser�o usados para algo.
	
	int maior(int um, int dois) {
		if(um > dois) {
			return um;
		}
		else {
			return dois;
		}
	}
	
	
	double soma (double um, double dois) {
		double s = um + dois;
		return s;
	}
	
}
