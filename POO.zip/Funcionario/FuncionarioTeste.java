package Funcionario;

public class FuncionarioTeste {

	public static void main(String[] args) {
		// TODO Auto-generated method stub

	}

}
