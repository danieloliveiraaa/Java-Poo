package Cachorro;

public class Cachorro {
	public String nome;
	public String raca;
	public int idade;
	
	
}
