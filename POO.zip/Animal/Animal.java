package Animal;

public class Animal {
	public String nome;
	public int idade;
	public String cor;
	
	
	void comer() {
		System.out.println("Comendo!");
	}
	
	void dormir() {
		System.out.println("Dormindo!");
	}
	
	void digestao() {
		System.out.println("Realizando digest�o!");
	}

}
