package Animal;

public class Cachorro extends Animal{
	
	void late() {
		System.out.println("Cachorro latiu! Au Au");
	}

}
