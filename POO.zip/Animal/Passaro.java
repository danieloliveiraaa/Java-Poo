package Animal;


//EXTENDS CARACERIZ HERAN�A
public class Passaro extends Animal{
	
	void voo() {
		System.out.println("O passaro "+nome+" est� voando!");
	}

}
