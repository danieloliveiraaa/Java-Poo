package Animal;

public class AnimalTeste {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		Cachorro cachorro1 = new Cachorro();
		
		cachorro1.nome = "Agenor";
		cachorro1.idade = 5;
		cachorro1.cor = "Bege";
		
		cachorro1.comer();
		cachorro1.dormir();
		cachorro1.digestao();
		
		
		Passaro passaro1 = new Passaro();
		
		
		

	}

}
