package Animal;

public class Jacare extends Animal{
	
	void botaOvos() {
		System.out.println("Jacar� "+nome+" botou ovos!");
	}
	
		
}
